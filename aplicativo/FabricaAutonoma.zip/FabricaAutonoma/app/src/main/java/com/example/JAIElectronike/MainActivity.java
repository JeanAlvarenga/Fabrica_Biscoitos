package com.example.JAIElectronike;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    //private TextView textView;
    private EditText editAdressIP;
    private EditText editIngrediente1;
    private EditText editIngrediente2;
    private EditText editIngrediente3;
    private Button buttonAdd;
    private CheckBox tipo;

    private String ip;
    private String objeto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editIngrediente1 = findViewById(R.id.editIngrediente1);
        editIngrediente2 = findViewById(R.id.editIngrediente2);
        editIngrediente3 = findViewById(R.id.editIngrediente3);
        editAdressIP = findViewById(R.id.addressIP);
        buttonAdd = findViewById(R.id.buttonAdd);
        tipo = findViewById(R.id.tipo);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    adicionar(v);
                } catch (UnknownHostException e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    public void adicionar(View view) throws UnknownHostException {
        String addressIP = editAdressIP.getText().toString();
        String ingrediente1 = editIngrediente1.getText().toString();
        String ingrediente2 = editIngrediente2.getText().toString();
        String ingrediente3 = editIngrediente3.getText().toString();
        //final String[] response = {"null"};
        ip = getIpAddress();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Socket socket = new Socket(addressIP, 9090);
                    //BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    InputStream inputStream = socket.getInputStream();
                    PrintWriter writer = new PrintWriter(socket.getOutputStream());
                    if(tipo.isChecked()){
                        objeto = formatDataAsJSON("Pedido", ip, "Recheado", ingrediente1, ingrediente2, ingrediente3);
                    }
                    else{
                        objeto = formatDataAsJSON("Pedido", ip,"Comum", ingrediente1, ingrediente2, ingrediente3);
                    }
                    writer.write(objeto);
                    writer.close();
                    //response[0] = reader.readLine(); //192.168.0.67
                    //String response = reader.toString(); //192.168.0.67
                    byte[] buffer = new byte[1024];
                    int size = inputStream.read(buffer);
                    String res =  new String(buffer,0,size);



                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d("MyApp", res);
                        }
                    });
                    socket.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        Toast.makeText(getApplicationContext(),"Foi!",Toast.LENGTH_SHORT).show();
    }

    private String formatDataAsJSON(String requisicao,String myIp, String tip, String ing1, String ing2, String ing3){
        final JSONObject root = new JSONObject();
        try {
            root.put("Requisicao",requisicao);
            root.put("ipClient", myIp);
            root.put("User","Jean");
            root.put("Password","123");
            root.put("Tipo",tip);
            root.put("Ing1",ing1);
            root.put("Ing2",ing2);
            root.put("Ing3",ing3);
            return root.toString();
        }catch(JSONException e1){
            Log.d("JWP","Can't format JSON");
        }
        return null;
    }
    public String getIpAddress() {
        String ipAddress = "";
        try {
            // Obter todas as interfaces de rede do dispositivo
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            // Percorrer as interfaces de rede
            for (NetworkInterface intf : interfaces) {
                // Obter todos os endereços de rede associados à interface de rede
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                // Percorrer os endereços de rede
                for (InetAddress addr : addrs) {
                    // Verificar se o endereço é IPv4 e não é um endereço de loopback
                    if (!addr.isLoopbackAddress() && addr instanceof Inet4Address) {
                        // Obter o endereço IP como uma string
                        ipAddress = addr.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ipAddress;
    }

}